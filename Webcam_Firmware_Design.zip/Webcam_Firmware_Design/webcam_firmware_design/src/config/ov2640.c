/*
 * ov2640.c
 *
 * Created: 3/4/2018 6:44:00 PM
 *  Author: ece-lab3
 */ 
